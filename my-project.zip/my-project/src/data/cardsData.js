
export const data = [{
    id: '1',
    url: '../src/assets/Earth.jpg',
    EnglishWord: 'World',
    Translate: 'Мир',
},
{
    id: '2',
    url: 'https://aqualife.ru/upload/iblock/230/230712de973388a811758eb2e6c61926.jpg',
    EnglishWord: 'Water',
    Translate: 'Вода',
},
{
    id: '3',
    url: 'https://aqualife.ru/upload/iblock/230/230712de973388a811758eb2e6c61926.jpg',
    EnglishWord: 'Rain',
    Translate: 'Дождь',
},
{
    id: '4',
    url: 'https://aqualife.ru/upload/iblock/230/230712de973388a811758eb2e6c61926.jpg',
    EnglishWord: 'Table',
    Translate: 'Стол',
},
{
    id: '5',
    url: './src/assets/chair.jpg',
    EnglishWord: 'Chair',
    Translate: 'Стул',
},
{
    id: '6',
    url: './src/assets/bench.jpg',
    EnglishWord: 'Bench',
    Translate: 'Скамейка',
},
{
    id: '7',
    url: './src/assets/blouse.jpg',
    EnglishWord: 'Blouse',
    Translate: 'Блузка',
},
{
    id: '8',
    url: './src/assets/children.jpg',
    EnglishWord: 'Children',
    Translate: 'Дети',
},
{
    id: '9',
    url: './src/assets/pants.jpg',
    EnglishWord: 'Pants',
    Translate: 'Штаны',
},
{
    id: '10',
    url: './src/assets/playground.jpg',
    EnglishWord: 'Playground',
    Translate: 'Детская площадка',
},
{
    id: '11',
    url: './src/assets/rain.jpg',
    EnglishWord: 'Rain',
    Translate: 'Дождь',
},
{
    id: '12',
    url: './src/assets/skirt.jpg',
    EnglishWord: 'Skirt',
    Translate: 'Юбка',
}
]